package com.api.agendaGil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendaGilApplicationTests {

	@Test
	void contextLoads() {
	}

}
